module.exports = {
  testEnvironment: 'node',
};
