/**
 * @file Login.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description
 *
 */
import React from "react";
import { useAuth0 } from "@auth0/auth0-react";

function Login() {
  console.log(`Login()`);
  const { isAuthenticated, loginWithRedirect } = useAuth0();

  function handleLogin() {
    console.log(`Login().handleLogin()`);
    loginWithRedirect();
  }

  return !isAuthenticated && <button onClick={handleLogin}>Log in</button>;
}

export default Login;
