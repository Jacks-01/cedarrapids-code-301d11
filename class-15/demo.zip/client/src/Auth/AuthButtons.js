/**
 * @file AuthButtons.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description
 *
 */
import React from "react";
import { useAuth0 } from "@auth0/auth0-react";
import Login from "./Login";
import LogoutButton from "./Logout";

/**
 * Returns the correct login/logout button based on user authentication
 * @returns {Component}
 */
function AuthButtons() {
  const { isAuthenticated } = useAuth0();
  console.log(`AuthButtons() isAuthenticated: ${isAuthenticated} `);

  //return isAuthenticated ? <LogoutButton /> : <Login />;
  if (isAuthenticated) {
    return <LogoutButton />;
  } else {
    return <Login />;
  }
}

export default AuthButtons;
