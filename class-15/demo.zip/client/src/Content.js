/**
 * @file Content.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description
 *
 */
import React from "react";
import axios from "axios";
import { withAuth0 } from "@auth0/auth0-react";

class Content extends React.Component {
  /**
   * Initialize the books array state attribute
   *
   * @param {object} props - the properties object
   */
  constructor(props) {
    super(props);
    this.state = {
      books: [],
    };
  }

  /**
   * Attempt to do an initial load of the books data.
   */
  async componentDidMount() {
    if (this.props.auth0.isAuthenticated) {
      const res = await this.props.auth0.getIdTokenClaims();
      const jwt = res.__raw; // two underscore characters

      const config = {
        headers: { Authorization: `Bearer ${jwt}` },
        method: "get",
        baseUrl: process.env.REACT_APP_BOOK_SERVER,
        email: "someemail@someplace.com",
      };
      // console.log(
      //   `Content.componentDidMount() config: ${JSON.stringify(config)}`
      // );

      await axios
        .get(process.env.REACT_APP_BOOK_SERVER, config)
        .then((res) => {
          this.setState({ books: res.data });
        })
        .catch((err) => {
          console.log(`Content.componentDidMount() ERROR: ${err.message}`);
        });
    }
  }

  /**
   * Draw the Content
   * @returns {Component}
   */
  render() {
    return (
      <>
        <h1>Books</h1>
        <ul>
          {this.state.books.map((book) => {
            return <li key={book._id}>{book.title}</li>;
          })}
        </ul>
      </>
    );
  }
}

export default withAuth0(Content);
