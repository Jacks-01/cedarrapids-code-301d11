/**
 * @file Profile.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description
 *
 */
import React from "react";
import { withAuth0 } from "@auth0/auth0-react";

class Profile extends React.Component {
  render() {
    return (
      <div>
        <p>Hello, {this.props.auth0.user.name}</p>
        <p>Your email address is {this.props.auth0.user.email}</p>
      </div>
    );
  }
}

export default withAuth0(Profile);
