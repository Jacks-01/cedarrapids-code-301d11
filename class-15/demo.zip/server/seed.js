const mongoose = require("mongoose");
require("dotenv").config();

mongoose.connect(process.env.MONGO_URL);

const Book = require("./models/bookModel");

async function seed() {
  // seed the database with some books, so I can retrieve them
  const myBook = new Book({
    title: "Cordell's Rebellion",
    description: "Old man gets cranky, starts a war.",
    status: "Published",
    email: "Unspecified",
  });
  myBook.save(function (err) {
    if (err) console.error(err);
    else console.log("saved Cordell's Rebellion");
  });

  // alternately...
  await Book.create({
    title: "Hour of Consequence",
    description:
      "Radio personality encourages stupidity and must face the repercussions",
    status: "Published",
    email: "Unspecified",
  });

  console.log("saved Hour of Consequence");

  mongoose.disconnect();
}

seed();
