/**
 * @file authorize.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description
 *
 */
"use strict";

const jwt = require("jsonwebtoken"); //auth
const jwksClient = require("jwks-rsa"); // auth

function verifyUser(request, response, next) {
  function valid(err, user) {
    request.user = user;
    next();
  }

  try {
    const token = request.headers.authorization.split(" ")[1];
    jwt.verify(token, getKey, {}, valid);
  } catch (err) {
    next("Not Authorized");
  }
}

/* ****************************************************************************
 HELPER METHODS pulled from jsonwebtoken documentation
 https://www.npmjs.com/package/jsonwebtoken
**************************************************************************** */

/**
 * Define a client.  This is a connection to your auth0 account
 * using the URL given in your dashboard.
 */
const client = jwksClient({
  jwksUri: process.env.JWKS_URI,
});

/**
 * Match the JWT's key to your Auth0 Account Key to validate it.
 *
 * @param {*} header
 * @param {*} callback
 */
function getKey(header, callback) {
  client.getSigningKey(header.kid, (err, key) => {
    const signingKey = key.publicKey || key.rsaPublicKey;
    callback(null, signingKey);
  });
}

module.exports = verifyUser;
