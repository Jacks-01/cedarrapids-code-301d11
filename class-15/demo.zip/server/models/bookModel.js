/**
 * @file bookModel.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description A book schema for MongoDB
 *
 */
"use strict";

const mongoose = require("mongoose");
const { Schema } = mongoose;

const bookSchema = new Schema({
  title: String,
  description: String,
  status: String,
  email: String,
});

const Book = mongoose.model("Book", bookSchema);

module.exports = Book;
