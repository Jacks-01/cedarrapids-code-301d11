/**
 * @file server.js
 * @date 2022-05-26
 * @author Code Fellows
 * @description
 *
 */
"use strict";

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const Book = require("./models/bookModel");
const verifyUser = require("./auth/authorize");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3001;

/* 
  Establish the mongoose connectivity
*/
mongoose.connect(process.env.MONGO_URL);
const db = mongoose.connection;
db.on("error", (err) => {
  console.error(`DB ERROR: ${err}`);
});
db.once("open", () => {
  console.log(`Connected to database`);
});

/*
This will run the verify code on every route automatically.
If the user is valid, they woll be in request.user in every
route.  If not, it will throw an error. 
*/
app.use(verifyUser);

// Test end point
app.get("/test", (req, res) => {
  console.log(`Requestes test`);
  res.send("test request received");
});

// Application end points
app.get("/books", handleGetBooks);
app.post("/books", handlePostBooks);
app.delete("/books/:id", handleDeleteBooks);
app.put("/books/:id", handlePutBooks);
app.get("/user", handleGetUser);

async function handleGetBooks(req, res) {
  console.log(`In handleGetBooks()`);
  try {
    const books = await Book.find();
    //console.log(`Sending ${JSON.stringify(books)}`);
    res.status(200).send(books);
  } catch (err) {
    console.error(err);
    res.status(400).send(`Could not find books: ${err.message}`);
  }
}
async function handlePostBooks(req, res) {
  console.log(`In handlePostBooks()`);
  const { title, description, status } = req.body;
  try {
    const newBook = await Book.create({ ...req.body, email: req.email });
    res.status(201).send(newBook);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
}
async function handleDeleteBooks(req, res) {
  console.log(`In handleDeleteBooks()`);
  const { id } = req.params;
  try {
    const book = await Book.findOne({ _id: id, email: req.user.email });
    if (!book) {
      res.status(400).send("Unable to delete book.");
    } else {
      await Book.findByIdAndDelete(id);
      res.status(204).send("Book deleted.");
    }
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
}
async function handlePutBooks(req, res) {
  console.log(`In handlePutBooks()`);
  const { id } = req.params;
  try {
    const book = await Book.findOne({ _id: id, email: req.user.email });
    if (!book) {
      res.status(400).send("Unable to update book.");
    } else {
      const updatedBook = await Book.findByIdAndUpdate(
        is,
        { ...req.body, email: req.user.email },
        { new: true, overwrite: true }
      );
      res.status(200).send(updatedBook);
    }
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error.");
  }
}

async function handleGetUser(req, res) {
  console.log(`In handleGetUser()`);
  res.send(req.user);
}

/*
    Start the Server
*/
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
